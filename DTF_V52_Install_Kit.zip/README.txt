DTF COMMAND HQ – FIRST TIME INSTALL KIT
1. Install Python 3.10+
2. Run EmpireInstaller_V52.py
3. Run DTF_Optimizer.bat
4. Edit .streamlit/secrets.toml
5. Double-click launch.bat
