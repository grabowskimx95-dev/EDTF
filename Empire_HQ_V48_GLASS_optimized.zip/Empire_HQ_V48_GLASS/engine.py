import os
import time
import json
import requests
import base64
import toml
from datetime import datetime, date
from moviepy.editor import AudioFileClip, ImageClip, CompositeVideoClip, ColorClip

DB_FILE = "empire_database.json"
LOG_FILE = "empire_activity.log"
ALERT_FILE = "alert_state.json"
SECRETS_FILE = os.path.join(os.path.dirname(__file__), ".streamlit", "secrets.toml")

ENGINE_DIR = os.path.dirname(__file__)
STAGING_DIR = os.path.join(ENGINE_DIR, "staging_output")
YOUTUBE_DIR = os.path.join(ENGINE_DIR, "youtube_scripts")
BRAIN_CONFIG_FILE = os.path.join(ENGINE_DIR, "brain_config.json")
ANALYTICS_FILE = os.path.join(ENGINE_DIR, "analytics.json")

MAX_LOG_SIZE = 5 * 1024 * 1024
LINK_CHECK_BATCH = 3
BRAIN_UPDATE_MIN_INTERVAL_SEC = 4 * 3600  # 4 hours

# ---------- LOGGING ----------

def rotate_logs_if_needed():
    if not os.path.exists(LOG_FILE):
        return
    try:
        size = os.path.getsize(LOG_FILE)
        if size > MAX_LOG_SIZE:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            archived = f"{LOG_FILE.rstrip('.log')}_{ts}.log"
            os.rename(LOG_FILE, archived)
    except Exception:
        pass

def log(msg):
    rotate_logs_if_needed()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{ts}] {msg}"
    print(entry)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")

# ---------- SECRETS ----------

def load_secrets():
    try:
        return toml.load(SECRETS_FILE)
    except Exception:
        log("❌ ERROR: missing or unreadable secrets.toml")
        return {}

# ---------- DB HELPERS ----------

def default_db():
    return {
        "db": [],
        "system_status": "RUNNING",
        "run_log": {},
        "stats": {
            "total_success": 0,
            "total_failed": 0,
            "avg_production_time_sec": 0.0,
            "last_success": None,
            "last_error": None,
            "consecutive_errors": 0,
            "last_scout": None
        },
        "health": {
            "broken_links": 0,
            "last_link_check": None
        }
    }

def load_db():
    if not os.path.exists(DB_FILE):
        return default_db()
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        log("❌ DB corrupted or unreadable. Recreating fresh DB.")
        return default_db()

    base = default_db()
    for k, v in base.items():
        if k not in data:
            data[k] = v
    data.setdefault("stats", base["stats"])
    data.setdefault("health", base["health"])
    data.setdefault("run_log", {})
    data.setdefault("db", [])
    data.setdefault("system_status", "RUNNING")

    now = datetime.utcnow().isoformat()
    for item in data["db"]:
        item.setdefault("id", f"{item.get('name','item')}_{int(datetime.utcnow().timestamp())}")
        item.setdefault("status", "Pending")
        item.setdefault("link", "")
        item.setdefault("created_at", now)
        item.setdefault("last_update", now)
        item.setdefault("fail_count", 0)
        item.setdefault("last_error", "")
        item.setdefault("channels", {})
        item.setdefault("link_status", "UNKNOWN")
        item.setdefault("link_last_check", None)
        item.setdefault("generated", {})
        item.setdefault("unit", "DigitalEmpire")
        item.setdefault("analytics", {})
        item.setdefault("affiliate_info", {})
    return data

def save_db(data):
    tmp_path = DB_FILE + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
    os.replace(tmp_path, DB_FILE)

# ---------- BRAIN CONFIG ----------

def default_brain_config():
    return {
        "persona_prompt_extra": "",
        "scouting_focus": {
            "priority_brands": [],
            "priority_categories": [],
            "ticket_mix": "balanced"
        },
        "last_update": None,
        "last_brain_run": None
    }

def load_brain_config():
    if not os.path.exists(BRAIN_CONFIG_FILE):
        return default_brain_config()
    try:
        with open(BRAIN_CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        base = default_brain_config()
        for k, v in base.items():
            if k not in cfg:
                cfg[k] = v
        return cfg
    except Exception:
        return default_brain_config()

def save_brain_config(cfg):
    tmp = BRAIN_CONFIG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4)
    os.replace(tmp, BRAIN_CONFIG_FILE)

# ---------- ANALYTICS ----------

def merge_external_analytics(data):
    if not os.path.exists(ANALYTICS_FILE):
        return
    try:
        with open(ANALYTICS_FILE, "r", encoding="utf-8") as f:
            analytics = json.load(f)
    except Exception as e:
        print(f"⚠️ Unable to read analytics.json: {e}")
        return

    if not isinstance(analytics, dict):
        print("⚠️ analytics.json must be a JSON object mapping ids/names to metrics.")
        return

    for item in data.get("db", []):
        aid = item.get("id")
        name = item.get("name")
        metrics = analytics.get(aid) or analytics.get(name)
        if metrics and isinstance(metrics, dict):
            item["analytics"] = metrics

def summarize_performance(data):
    perf_items = []
    for item in data.get("db", []):
        a = item.get("analytics") or {}
        if not a:
            continue
        clicks = float(a.get("clicks", 0))
        impressions = float(a.get("impressions", 0))
        ctr = float(a.get("ctr", clicks / impressions if impressions > 0 else 0.0))
        conversions = float(a.get("conversions", 0))
        avg_watch = float(a.get("avg_watch_time", 0))
        perf_items.append({
            "id": item.get("id"),
            "name": item.get("name"),
            "clicks": clicks,
            "impressions": impressions,
            "ctr": ctr,
            "conversions": conversions,
            "avg_watch_time": avg_watch
        })

    if not perf_items:
        return {
            "top": [],
            "bottom": [],
            "avg_ctr": None,
            "avg_watch": None
        }

    perf_items_sorted = sorted(perf_items, key=lambda x: x["ctr"], reverse=True)
    top = perf_items_sorted[:5]

    with_impressions = [x for x in perf_items if x["impressions"] > 0]
    if with_impressions:
        bottom = sorted(with_impressions, key=lambda x: x["ctr"])[:5]
    else:
        bottom = []

    avg_ctr = sum(x["ctr"] for x in perf_items) / len(perf_items)
    avg_watch_vals = [x["avg_watch_time"] for x in perf_items if x["avg_watch_time"] > 0]
    avg_watch = sum(avg_watch_vals) / len(avg_watch_vals) if avg_watch_vals else None

    return {
        "top": top,
        "bottom": bottom,
        "avg_ctr": avg_ctr,
        "avg_watch": avg_watch
    }

# ---------- ALERT STATE ----------

def load_alert_state():
    if not os.path.exists(ALERT_FILE):
        return {
            "level": "OK",
            "message": "All systems nominal.",
            "updated_at": None,
            "last_notified_critical_at": None
        }
    try:
        with open(ALERT_FILE, "r", encoding="utf-8") as f:
            state = json.load(f)
        state.setdefault("level", "OK")
        state.setdefault("message", "All systems nominal.")
        state.setdefault("last_notified_critical_at", None)
        return state
    except Exception:
        return {
            "level": "OK",
            "message": "All systems nominal.",
            "updated_at": None,
            "last_notified_critical_at": None
        }

def save_alert_state(state):
    tmp_path = ALERT_FILE + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)
    os.replace(tmp_path, ALERT_FILE)

def send_webhook(message, url):
    try:
        requests.post(url, json={"text": message}, timeout=10)
    except Exception as e:
        log(f"Webhook failed: {e}")

def update_alert_state(data, runs_today, daily_limit, secrets):
    stats = data.get("stats", {})
    health = data.get("health", {})
    system_status = data.get("system_status", "RUNNING")
    broken_links = int(health.get("broken_links", 0))

    level = "OK"
    message = "All systems nominal."

    now = datetime.utcnow()
    now_iso = now.isoformat()

    last_error_ts = stats.get("last_error")
    recent_error = False
    if last_error_ts:
        try:
            dt_err = datetime.fromisoformat(last_error_ts)
            if (now - dt_err).total_seconds() < 600:
                recent_error = True
        except Exception:
            pass

    if system_status == "STOPPED":
        level = "CRITICAL"
        message = "Engine kill switch is active."
    elif runs_today >= daily_limit:
        level = "WARNING"
        message = f"Daily run limit reached ({runs_today}/{daily_limit})."
    elif broken_links > 0:
        level = "WARNING"
        message = f"{broken_links} broken links detected."
    elif recent_error or stats.get("consecutive_errors", 0) >= 3:
        level = "WARNING"
        message = "Recent production errors detected."

    new_state = {
        "level": level,
        "message": message,
        "updated_at": now_iso
    }

    prev = load_alert_state()
    new_state["last_notified_critical_at"] = prev.get("last_notified_critical_at")

    webhook_url = secrets.get("alert_webhook_url")
    if level == "CRITICAL" and webhook_url:
        should_notify = False
        last_notified = prev.get("last_notified_critical_at")
        if not last_notified:
            should_notify = True
        else:
            try:
                dt_last = datetime.fromisoformat(last_notified)
                if (now - dt_last).total_seconds() > 3600:
                    should_notify = True
            except Exception:
                should_notify = True
        if should_notify:
            send_webhook(f"🚨 Empire OS Alert: {message}", webhook_url)
            new_state["last_notified_critical_at"] = now_iso

    save_alert_state(new_state)

# ---------- STATS & RUN LOG ----------

def update_stats(data, success, duration_sec=None):
    stats = data.setdefault("stats", {
        "total_success": 0,
        "total_failed": 0,
        "avg_production_time_sec": 0.0,
        "last_success": None,
        "last_error": None,
        "consecutive_errors": 0,
        "last_scout": None
    })
    now_iso = datetime.utcnow().isoformat()
    if success:
        stats["total_success"] = int(stats.get("total_success", 0)) + 1
        stats["last_success"] = now_iso
        stats["consecutive_errors"] = 0
        if duration_sec is not None:
            prev_total = stats["total_success"] + stats.get("total_failed", 0) - 1
            prev_avg = float(stats.get("avg_production_time_sec", 0.0))
            if prev_total <= 0:
                stats["avg_production_time_sec"] = float(duration_sec)
            else:
                stats["avg_production_time_sec"] = float(
                    (prev_avg * prev_total + duration_sec) / (prev_total + 1)
                )
    else:
        stats["total_failed"] = int(stats.get("total_failed", 0)) + 1
        stats["last_error"] = now_iso
        stats["consecutive_errors"] = int(stats.get("consecutive_errors", 0)) + 1

def bump_run_log(data, success):
    today_key = str(date.today())
    run_log = data.setdefault("run_log", {})
    day = run_log.get(today_key, {"success": 0, "failed": 0, "total": 0})
    if success:
        day["success"] = int(day.get("success", 0)) + 1
    else:
        day["failed"] = int(day.get("failed", 0)) + 1
    day["total"] = int(day.get("success", 0)) + int(day.get("failed", 0))
    run_log[today_key] = day

# ---------- RETRY DECORATOR ----------

def retry_api(func, retries=3, delay=10):
    def wrapper(*args, **kwargs):
        for i in range(retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log(f"⚠️ API Error (Attempt {i+1}/{retries}): {e}")
                time.sleep(delay)
        log(f"❌ API failed after {retries} attempts.")
        return None
    return wrapper

# ---------- EXTERNAL INTEGRATIONS ----------

@retry_api
def run_scout_real(query, key):
    log(f"🔭 Scouting: {query}")
    url = "https://api.perplexity.ai/chat/completions"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    body = {
        "model": "llama-3.1-sonar-large-128k-online",
        "messages": [
            {
                "role": "user",
                "content": (
                    f"List 5 trending professional-grade tool or tool-related products for: {query}. "
                    "Prefer products that are widely available on major retailers like Amazon, Home Depot, "
                    "Lowe's, Acme Tools, or other common affiliate programs. "
                    "Return only a simple comma-separated list of product names, no extra text."
                )
            }
        ]
    }
    res = requests.post(url, json=body, headers=headers, timeout=60)
    res.raise_for_status()
    text = res.json()["choices"][0]["message"]["content"]
    return [x.strip() for x in text.split(",") if x.strip()]

@retry_api
def get_affiliate_program_info(product_name, key):
    log(f"🔗 Finding affiliate program for: {product_name}")
    url = "https://api.perplexity.ai/chat/completions"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    prompt = (
        f"For the tool or product named: \"{product_name}\"\n"
        "1) Identify ONE major online retailer where this product (or the closest real equivalent) is actually sold "
        "(Amazon, Home Depot, Lowe's, Acme Tools, etc.).\n"
        "2) Find the public signup/info page for that retailer's affiliate, partner, influencer, or associate program.\n"
        "If there is no clear affiliate program, say so.\n\n"
        "Return ONLY valid JSON like this:\n"
        "{\n"
        "  \"merchant_name\": \"Amazon\",\n"
        "  \"product_url_example\": \"https://www.amazon.com/…\",\n"
        "  \"affiliate_program_url\": \"https://affiliate-program.amazon.com/\",\n"
        "  \"has_affiliate_program\": true,\n"
        "  \"notes\": \"Short note on how this program works or any caveats.\"\n"
        "}\n"
    )
    body = {
        "model": "llama-3.1-sonar-large-128k-online",
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }
    res = requests.post(url, json=body, headers=headers, timeout=60)
    res.raise_for_status()
    text = res.json()["choices"][0]["message"]["content"]
    try:
        info = json.loads(text)
        if not isinstance(info, dict):
            raise ValueError("Not a JSON object")
    except Exception as e:
        log(f"   -> ⚠️ Could not parse affiliate info JSON for {product_name}: {e}")
        info = {
            "merchant_name": "",
            "product_url_example": "",
            "affiliate_program_url": "",
            "has_affiliate_program": False,
            "notes": "Failed to parse affiliate info."
        }
    info.setdefault("merchant_name", "")
    info.setdefault("product_url_example", "")
    info.setdefault("affiliate_program_url", "")
    info.setdefault("has_affiliate_program", bool(info.get("affiliate_program_url")))
    info.setdefault("notes", "")
    return info

def ai_quality_check(item_name, keys):
    log(f"🤖 Quality check (placeholder) for: {item_name}")
    return {"result": "ok", "score": 0.9}

def publish_to_wordpress(item, keys):
    wp_url = keys.get("wp_url", "").rstrip("/")
    wp_user = keys.get("wp_user")
    wp_pass = keys.get("wp_pass")

    if not wp_url or not wp_user or not wp_pass:
        log("   -> ❌ WordPress credentials missing; cannot publish.")
        ch = item.setdefault("channels", {})
        ch["wordpress"] = {"status": "Error", "reason": "Missing credentials"}
        return False

    api_url = f"{wp_url}/wp-json/wp/v2/posts"

    credentials = f"{wp_user}:{wp_pass}".encode("utf-8")
    token = base64.b64encode(credentials).decode("utf-8")

    generated = item.get("generated", {}) or {}
    content_html = generated.get("blog_html", "")
    if not content_html:
        log("   -> ⚠️ No blog_html in generated content; publishing empty body.")
        content_html = ""

    payload = {
        "title": item.get("name", "Untitled DTF Tool Review"),
        "content": content_html,
        "status": "publish"
    }

    headers = {
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json"
    }

    try:
        log(f"   -> 🚀 Publishing to WordPress at {api_url} ...")
        res = requests.post(api_url, headers=headers, json=payload, timeout=60)
        if res.status_code not in (200, 201):
            log(f"   -> ❌ WordPress returned {res.status_code}: {res.text[:200]}")
            ch = item.setdefault("channels", {})
            ch["wordpress"] = {
                "status": "Error",
                "reason": f"HTTP {res.status_code}",
            }
            return False

        data = res.json()
        post_id = data.get("id")
        link = data.get("link")

        ch = item.setdefault("channels", {})
        ch["wordpress"] = {
            "status": "Published",
            "post_id": post_id,
            "url": link
        }

        log(f"   -> ✅ WordPress post created: id={post_id}, url={link}")
        return True
    except Exception as e:
        log(f"   -> ❌ WordPress publish failed: {e}")
        ch = item.setdefault("channels", {})
        ch["wordpress"] = {
            "status": "Error",
            "reason": str(e),
        }
        return False

def safe_slug(name):
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in (name or "item"))

def write_staging_preview(item):
    generated = item.get("generated") or {}
    html = generated.get("blog_html", "").strip()
    if not html:
        log("   -> ⚠️ No blog_html to write preview file.")
        return None
    slug = safe_slug(item.get("name"))
    short_id = (item.get("id") or "item")[:8]
    filename = f"{slug}_{short_id}.html"
    path = os.path.join(STAGING_DIR, filename)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write("<!DOCTYPE html><html><head><meta charset='utf-8'><title>")
            f.write(item.get("name", "Preview"))
            f.write("</title></head><body>")
            f.write(html)
            f.write("</body></html>")
        log(f"   -> 🧪 Staging HTML preview written: {path}")
        ch = item.setdefault("channels", {})
        wp_ch = ch.setdefault("wordpress", {})
        wp_ch["preview_file"] = path
        return path
    except Exception as e:
        log(f"   -> ❌ Failed to write staging preview: {e}")
        return None

def export_youtube_script(item):
    generated = item.get("generated") or {}
    script = generated.get("video_script", "").strip()
    ch = item.setdefault("channels", {})
    if not script:
        log("   -> ⚠️ No video_script available; skipping YouTube export.")
        ch.setdefault("youtube", {"status": "NoScript"})
        return False
    slug = safe_slug(item.get("name"))
    short_id = (item.get("id") or "item")[:8]
    filename = f"{slug}_{short_id}.txt"
    path = os.path.join(YOUTUBE_DIR, filename)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(script)
        ch["youtube"] = {"status": "ScriptReady", "file": path}
        log(f"   -> 🎬 YouTube script exported: {path}")
        return True
    except Exception as e:
        log(f"   -> ❌ Failed to write YouTube script: {e}")
        ch["youtube"] = {"status": "Error", "reason": str(e)}
        return False

# ---------- COGNITIVE ADJUSTMENT AGENT ----------

def maybe_run_brain_update(data, secrets):
    brain = load_brain_config()
    now = datetime.utcnow()
    last_run = brain.get("last_brain_run")
    if last_run:
        try:
            dt_last = datetime.fromisoformat(last_run)
            if (now - dt_last).total_seconds() < BRAIN_UPDATE_MIN_INTERVAL_SEC:
                return
        except Exception:
            pass

    if not secrets.get("openai_key"):
        return

    perf = summarize_performance(data)
    top = perf.get("top") or []
    bottom = perf.get("bottom") or []
    if not top and not bottom:
        return

    avg_ctr = perf.get("avg_ctr")
    avg_watch = perf.get("avg_watch")

    def pack_list(items):
        out = []
        for x in items:
            out.append(
                f"{x['name']} (ctr={x['ctr']:.3f}, clicks={int(x['clicks'])}, conv={int(x['conversions'])})"
            )
        return "; ".join(out)

    top_str = pack_list(top)
    bottom_str = pack_list(bottom)

    current_extra = brain.get("persona_prompt_extra", "")
    current_focus = brain.get("scouting_focus", {})

    avg_ctr_str = f"{avg_ctr:.3f}" if avg_ctr is not None else "0.000"
    avg_watch_str = f"{avg_watch:.1f}" if avg_watch is not None else "0.0"

    summary_text = (
        f"Average CTR: {avg_ctr_str}, "
        f"Average watch time: {avg_watch_str}.\n"
        f"Top performers: {top_str or 'none'}.\n"
        f"Bottom performers: {bottom_str or 'none'}.\n"
        f"Current persona_prompt_extra: {current_extra}\n"
        f"Current scouting_focus: {json.dumps(current_focus)}"
    )

    try:
        url = "https://api.openai.com/v1/chat/completions"
        headers_oa = {
            "Authorization": f"Bearer {secrets['openai_key']}",
            "Content-Type": "application/json"
        }
        sys_msg = (
            "You are an optimization brain for a blue-collar tool review brand called DTF.\n"
            "You receive real performance metrics for recent content.\n"
            "Your job is to ADJUST the content engine's behavior:\n"
            "- Tighten or tweak persona instructions based on what gets better CTR and watch time.\n"
            "- Suggest which brands / categories to prioritize in scouting.\n"
            "- Recommend whether to lean more into high-ticket or low-ticket offers.\n\n"
            "Return ONLY a valid JSON object with:\n"
            "{\n"
            "  \"persona_prompt_extra\": \"one short paragraph of extra style/performance rules\",\n"
            "  \"scouting_focus\": {\n"
            "    \"priority_brands\": [\"Milwaukee\", \"DeWalt\"],\n"
            "    \"priority_categories\": [\"power tools\", \"storage\"],\n"
            "    \"ticket_mix\": \"balanced\"\n"
            "  }\n"
            "}\n"
            "Keep it practical and aligned with DTF's no-fluff, jobsite voice."
        )
        user_msg = (
            "Here is the recent performance summary for our content. "
            "Use this to adjust how we talk and what we scout for next.\n\n"
            f"{summary_text}"
        )
        body = {
            "model": secrets.get("openai_model", "gpt-4.1-mini"),
            "messages": [
                {"role": "system", "content": sys_msg},
                {"role": "user", "content": user_msg}
            ],
            "temperature": 0.4
        }

        log("🧠 Running Cognitive Adjustment Agent (brain update)...")
        res = requests.post(url, json=body, headers=headers_oa, timeout=120)
        res.raise_for_status()
        text = res.json()["choices"][0]["message"]["content"]
        new_cfg = json.loads(text)
        if not isinstance(new_cfg, dict):
            raise ValueError("Brain response not a JSON object")

        persona_extra = new_cfg.get("persona_prompt_extra", "") or ""
        scouting_focus = new_cfg.get("scouting_focus") or {}

        brain["persona_prompt_extra"] = persona_extra
        brain["scouting_focus"] = scouting_focus
        brain["last_update"] = datetime.utcnow().isoformat()
        brain["last_brain_run"] = brain["last_update"]

        save_brain_config(brain)
        log("✅ Brain config updated from analytics.")
    except Exception as e:
        log(f"⚠️ Cognitive Adjustment Agent failed: {e}")
        brain["last_brain_run"] = datetime.utcnow().isoformat()
        save_brain_config(brain)

# ---------- PRODUCTION PIPELINE ----------

def run_production_real(item, keys, mode="live"):
    name = item["name"]
    log(f"🏗️ Manufacturing: {name} (mode={mode})")

    brain = load_brain_config()
    persona_extra = brain.get("persona_prompt_extra", "") or ""

    try:
        url = "https://api.openai.com/v1/chat/completions"
        headers_oa = {
            "Authorization": f"Bearer {keys['openai_key']}",
            "Content-Type": "application/json"
        }
        base_sys_prompt = (
            "You are the content engine for a digital brand built around a real contracting crew "
            "called 'Design To Finish Contracting (DTF)'. DTF is blue-collar, no-fluff, and talks "
            "like real contractors, not corporate marketers.\n\n"
            "Write in a short, straight-to-the-point style:\n"
            "- Plain language, jobsite tone, PG-13 (no slurs, no hardcore profanity).\n"
            "- No long intros, no filler paragraphs, no fake hype.\n"
            "- Clearly say what a tool is good for, where it falls short, and who should NOT buy it.\n"
            "- Be honest about pros and cons; don’t pretend everything is amazing.\n"
            "- Mention DTF or 'the DTF crew' where it fits, but don’t spam the name.\n"
            "- It’s fine to say something is just 'fine' or 'mid' if that’s the truth.\n\n"
        )
        sys_prompt = (
            base_sys_prompt
            + (persona_extra + "\n\n" if persona_extra else "")
            + "For each product, return ONLY a valid JSON object:\n"
              "{\n"
              "  \"blog_html\": \"<p>...</p>\",\n"
              "  \"video_script\": \"...\",\n"
              "  \"social_caption\": \"...\",\n"
              "  \"email_snippet\": \"...\"\n"
              "}\n"
              "Requirements:\n"
              "- 'blog_html': about 600–1200 words, broken into clear sections with headings.\n"
              "- 'video_script': a 30–60 second vertical video script in DTF voice.\n"
              "- 'social_caption': a short hook + value + soft CTA, DTF-branded.\n"
              "- 'email_snippet': 2–5 sentences that could fit in a weekly tool roundup.\n"
              "No backticks, no markdown, no commentary outside the JSON. HTML must be well-formed."
        )
        user_prompt = f"Create a DTF-branded tool review and content package for the product: {name}."

        body = {
            "model": keys.get("openai_model", "gpt-4.1-mini"),
            "messages": [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.7
        }

        log("   -> ✍️ Requesting content from OpenAI...")
        res = requests.post(url, json=body, headers=headers_oa, timeout=120)
        res.raise_for_status()
        text = res.json()["choices"][0]["message"]["content"]

        try:
            content = json.loads(text)
            if not isinstance(content, dict):
                raise ValueError("OpenAI response was not a JSON object.")
        except Exception as e:
            log(f"   -> ❌ OpenAI response not valid JSON: {e}")
            content = {
                "blog_html": "",
                "video_script": "",
                "social_caption": "",
                "email_snippet": ""
            }

        content.setdefault("blog_html", "")
        content.setdefault("video_script", "")
        content.setdefault("social_caption", "")
        content.setdefault("email_snippet", "")

        item["generated"] = content
        log("   -> ✅ Content JSON stored on item.")
    except Exception as e:
        log(f"   -> ❌ OpenAI generation failed: {e}")
        raise

    qc = ai_quality_check(name, keys)
    log(f"   -> 🤖 Quality result: {qc.get('result')} (score={qc.get('score')})")

    export_youtube_script(item)
    write_staging_preview(item)

    ch = item.setdefault("channels", {})
    if mode == "staging":
        log("   -> 🧪 STAGING MODE: content not published (virtual only).")
        wp_ch = ch.setdefault("wordpress", {})
        if "status" not in wp_ch:
            wp_ch["status"] = "Staged"
        return True
    else:
        ok = publish_to_wordpress(item, keys)
        return ok

# ---------- LINK HEALTH CHECK ----------

def check_link_health(data):
    items = [x for x in data.get("db", []) if x.get("link")]
    if not items:
        return
    def sort_key(i):
        v = i.get("link_last_check")
        if not v:
            return datetime.min
        try:
            return datetime.fromisoformat(v)
        except Exception:
            return datetime.min
    items = sorted(items, key=sort_key)
    to_check = items[:LINK_CHECK_BATCH]

    broken = 0
    now_iso = datetime.utcnow().isoformat()
    for item in to_check:
        url = item.get("link")
        try:
            resp = requests.head(url, allow_redirects=True, timeout=8)
            status = resp.status_code
            if 200 <= status < 400:
                item["link_status"] = "OK"
            else:
                item["link_status"] = "BROKEN"
        except Exception:
            item["link_status"] = "BROKEN"
        item["link_last_check"] = now_iso

    for item in data.get("db", []):
        if item.get("link_status") == "BROKEN":
            broken += 1

    health = data.setdefault("health", {})
    health["broken_links"] = broken
    health["last_link_check"] = now_iso

# ---------- DYNAMIC SCOUTING QUERY ----------

def build_scout_query(brain_cfg, perf_summary):
    focus = brain_cfg.get("scouting_focus", {})
    brands = focus.get("priority_brands") or []
    cats = focus.get("priority_categories") or []
    ticket_mix = (focus.get("ticket_mix") or "balanced").lower()

    top = perf_summary.get("top") or []
    top_names = [x["name"] for x in top]

    parts = ["power tools", "jobsite gear"]
    if brands:
        parts.append("brands: " + ", ".join(brands[:3]))
    if cats:
        parts.append("categories: " + ", ".join(cats[:3]))
    if top_names:
        parts.append("similar to: " + ", ".join(top_names[:3]))

    if "high" in ticket_mix:
        parts.append("high-ticket professional tools")
    elif "low" in ticket_mix:
        parts.append("entry-level and mid-ticket tools")

    query = " | ".join(parts)
    return query

# ---------- MAIN LOOP ----------

def autopilot_loop():
    log("--- ENGINE V48 STARTED (Digital Empire / DTF, Agentic) ---")

    os.makedirs(STAGING_DIR, exist_ok=True)
    os.makedirs(YOUTUBE_DIR, exist_ok=True)

    while True:
        try:
            secrets = load_secrets()
            if not secrets:
                time.sleep(10)
                continue

            required = ["pplx_key", "openai_key"]
            missing = [k for k in required if not secrets.get(k)]
            if missing:
                log(f"❌ Missing secrets: {', '.join(missing)}. Waiting for configuration...")
                time.sleep(60)
                continue

            daily_limit = int(secrets.get("daily_run_limit", 10))
            mode = secrets.get("mode", "live")
            min_pending = int(secrets.get("min_pending_threshold", 3))

            data = load_db()
            data.setdefault("db", [])
            data.setdefault("stats", default_db()["stats"])
            data.setdefault("health", default_db()["health"])

            merge_external_analytics(data)

            if data["system_status"] == "STOPPED":
                today_key = str(date.today())
                day_log = data.get("run_log", {}).get(today_key, {})
                runs_today = int(day_log.get("total", 0))
                update_alert_state(data, runs_today, daily_limit, secrets)
                log("🛑 KILL SWITCH ACTIVE. Sleeping...")
                save_db(data)
                time.sleep(60)
                continue

            today_key = str(date.today())
            day_log = data.get("run_log", {}).get(today_key, {})
            runs_today = int(day_log.get("total", 0))

            if runs_today >= daily_limit:
                update_alert_state(data, runs_today, daily_limit, secrets)
                log(f"⏳ Daily run limit reached ({runs_today}/{daily_limit}). Sleeping...")
                save_db(data)
                time.sleep(600)
                continue

            # Only process items that are Ready AND have a non-empty affiliate link
            ready = [
                x for x in data["db"]
                if x.get("status") == "Ready"
                and x.get("unit", "DigitalEmpire") == "DigitalEmpire"
                and x.get("link")
            ]

            # Downgrade any bogus Ready items with no link
            for item in data["db"]:
                if item.get("status") == "Ready" and not item.get("link"):
                    item["status"] = "Pending"
                    item["last_update"] = datetime.utcnow().isoformat()
                    item["last_error"] = "Missing affiliate link; cannot run production."

            if ready:
                for item in ready:
                    start = datetime.utcnow().timestamp()
                    success = False
                    try:
                        success = run_production_real(item, secrets, mode=mode)
                    except Exception as e:
                        log(f"🔥 Production error for {item.get('name')}: {e}")
                        success = False

                    duration = datetime.utcnow().timestamp() - start
                    update_stats(data, success, duration_sec=duration)
                    bump_run_log(data, success)

                    for x in data["db"]:
                        if x.get("id") == item.get("id"):
                            if success:
                                x["status"] = "Published"
                                x["last_update"] = datetime.utcnow().isoformat()
                                x["last_error"] = ""
                            else:
                                x["status"] = "Failed"
                                x["fail_count"] = int(x.get("fail_count", 0)) + 1
                                x["last_error"] = f"Production failed at {datetime.utcnow().isoformat()}"

                    today_key = str(date.today())
                    day_log = data.get("run_log", {}).get(today_key, {})
                    runs_today = int(day_log.get("total", 0))
                    save_db(data)
                    update_alert_state(data, runs_today, daily_limit, secrets)

                    if runs_today >= daily_limit:
                        log(f"⏳ Daily run limit reached while processing items ({runs_today}/{daily_limit}).")
                        break

                check_link_health(data)
                save_db(data)
                perf_summary = summarize_performance(data)
                maybe_run_brain_update(data, secrets)
                today_key = str(date.today())
                day_log = data.get("run_log", {}).get(today_key, {})
                runs_today = int(day_log.get("total", 0))
                update_alert_state(data, runs_today, daily_limit, secrets)
                time.sleep(10)
                continue

            pending_count = sum(
                1 for x in data["db"]
                if x.get("status") == "Pending"
                and x.get("unit", "DigitalEmpire") == "DigitalEmpire"
            )

            stats = data.setdefault("stats", default_db()["stats"])
            last_scout = stats.get("last_scout")
            can_scout = True
            if last_scout:
                try:
                    dt_ls = datetime.fromisoformat(last_scout)
                    if (datetime.utcnow() - dt_ls).total_seconds() < 3600:
                        can_scout = False
                except Exception:
                    pass

            if pending_count < min_pending and can_scout:
                perf_summary = summarize_performance(data)
                brain_cfg = load_brain_config()
                query = build_scout_query(brain_cfg, perf_summary)
                log(f"Pipeline below threshold ({pending_count} < {min_pending}). Auto-scouting tools with agentic query...")
                items = run_scout_real(query, secrets.get("pplx_key"))
                if items:
                    existing_names = {x.get("name") for x in data["db"]}
                    added = 0
                    now_iso = datetime.utcnow().isoformat()
                    for name in items:
                        if not name or name in existing_names:
                            continue

                        aff_info = get_affiliate_program_info(name, secrets.get("pplx_key")) or {}

                        data["db"].append({
                            "id": f"{name}_{int(datetime.utcnow().timestamp())}",
                            "name": name,
                            "status": "AffiliateReview",
                            "link": "",
                            "created_at": now_iso,
                            "last_update": now_iso,
                            "fail_count": 0,
                            "last_error": "",
                            "channels": {},
                            "link_status": "UNKNOWN",
                            "link_last_check": None,
                            "generated": {},
                            "unit": "DigitalEmpire",
                            "analytics": {},
                            "affiliate_info": aff_info
                        })
                        added += 1
                    stats["last_scout"] = now_iso
                    log(f"Added {added} new items to AffiliateReview queue.")
                    save_db(data)

            check_link_health(data)
            save_db(data)

            perf_summary = summarize_performance(data)
            maybe_run_brain_update(data, secrets)

            today_key = str(date.today())
            day_log = data.get("run_log", {}).get(today_key, {})
            runs_today = int(day_log.get("total", 0))
            update_alert_state(data, runs_today, daily_limit, secrets)

            time.sleep(60)

        except Exception as e:
            log(f"🔥 CRITICAL ENGINE ERROR: {e}")
            time.sleep(60)

if __name__ == "__main__":
    autopilot_loop()
