import os
import json
from datetime import datetime
import streamlit as st
import pandas as pd

DB_FILE = "empire_database.json"
LOG_FILE = "empire_activity.log"

# ---------- HELPERS ----------

def load_json(path, default=None):
    if default is None:
        default = {}
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
    os.replace(tmp, path)

def normalize_items(db_data):
    changed = False
    now = datetime.utcnow().isoformat()
    for item in db_data.get("db", []):
        if "id" not in item:
            item["id"] = f"{item.get('name','item')}_{int(datetime.utcnow().timestamp())}"
            changed = True
        item.setdefault("status", "Pending")
        item.setdefault("link", "")
        item.setdefault("created_at", now)
        item.setdefault("last_update", now)
        item.setdefault("fail_count", 0)
        item.setdefault("last_error", "")
        item.setdefault("channels", {})
        item.setdefault("link_status", "UNKNOWN")
        item.setdefault("link_last_check", None)
        item.setdefault("generated", {})
        item.setdefault("unit", "DigitalEmpire")
        item.setdefault("affiliate_info", {})
    return changed

# ---------- MAIN APP ----------

st.set_page_config(page_title="Empire HQ V48 - DTF Digital Empire", layout="wide")
st.title("Empire HQ V48 - DTF Digital Empire")
st.caption("DTF-branded digital tool review engine • Digital Empire Mode Only")

db = load_json(DB_FILE, {"db": [], "stats": {}, "health": {}, "run_log": {}})
if "db" not in db:
    db["db"] = []
if normalize_items(db):
    save_json(DB_FILE, db)

# Affiliate review notification
aff_review_count = sum(1 for x in db.get("db", []) if x.get("status") == "AffiliateReview")
if aff_review_count > 0:
    st.sidebar.warning(f"🔔 {aff_review_count} new affiliate applications to review")
    st.info(
        f"🔔 You have **{aff_review_count}** tools waiting in the Affiliate Queue. "
        "Open the **🤝 Affiliate Queue** tab to review programs and paste your affiliate links."
    )

tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8 = st.tabs([
    "⚡ Link Input",
    "📜 Live Logs",
    "📊 Pipeline",
    "🧪 Failed / Review",
    "📄 Content Viewer",
    "🚀 Launchpad",
    "📧 DTF Newsweek",
    "🤝 Affiliate Queue"
])

# ---------- TAB 1: LINK INPUT ----------

with tab1:
    st.subheader("⚡ Link Input (Your Unique Affiliate Links Only)")
    st.write("No tool goes live until you paste your own affiliate link. This tab is the gatekeeper.")

    items_for_links = [
        x for x in db.get("db", [])
        if x.get("unit") == "DigitalEmpire"
        and x.get("status") in ("Pending", "Ready", "AffiliateReview")
    ]

    if not items_for_links:
        st.info("No items needing links yet. The engine will scout tools automatically and put them into the Affiliate Queue.")
    else:
        rows = []
        for it in items_for_links:
            aff = it.get("affiliate_info") or {}
            rows.append({
                "id": it.get("id"),
                "name": it.get("name"),
                "status": it.get("status"),
                "merchant_name": aff.get("merchant_name", ""),
                "link": it.get("link", "")
            })
        df = pd.DataFrame(rows)
        st.dataframe(df[["name", "status", "merchant_name", "link"]], use_container_width=True)

        st.markdown("----")
        st.markdown("### Edit links")

        for row in rows:
            st.markdown(f"**{row['name']}**  _({row['merchant_name'] or 'Merchant unknown'})_")
            new_link = st.text_input(
                "Affiliate link:",
                value=row["link"],
                key=f"link_input_{row['id']}"
            )
            if st.button("💾 Save link", key=f"save_link_{row['id']}"):
                live_db = load_json(DB_FILE, {"db": []})
                for item in live_db.get("db", []):
                    if item.get("id") == row["id"]:
                        item["link"] = new_link.strip()
                        # Status rule: link present -> Ready, no link -> Pending (or stay AffiliateReview)
                        if new_link.strip():
                            # Only move out of AffiliateReview once you're ready
                            if item.get("status") == "AffiliateReview":
                                item["status"] = "Ready"
                            else:
                                item["status"] = "Ready"
                        else:
                            if item.get("status") != "AffiliateReview":
                                item["status"] = "Pending"
                        item["last_update"] = datetime.utcnow().isoformat()
                        item["last_error"] = ""
                        break
                save_json(DB_FILE, live_db)
                st.success("Link saved. Engine will only produce content once status is Ready and link is set.")
                st.experimental_rerun()
            st.markdown("---")

# ---------- TAB 2: LIVE LOGS ----------

with tab2:
    st.subheader("📜 Live Logs")
    if not os.path.exists(LOG_FILE):
        st.info("No log file yet. Start the engine to see activity here.")
    else:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
        tail = "".join(lines[-400:])
        st.code(tail or "(log empty)", language="text")

# ---------- TAB 3: PIPELINE ----------

with tab3:
    st.subheader("📊 Pipeline Overview")
    items = db.get("db", [])
    if not items:
        st.info("No items in the database yet.")
    else:
        rows = []
        for it in items:
            rows.append({
                "name": it.get("name"),
                "status": it.get("status"),
                "unit": it.get("unit"),
                "link": it.get("link"),
                "link_status": it.get("link_status"),
                "fail_count": it.get("fail_count", 0),
                "last_error": it.get("last_error", ""),
                "created_at": it.get("created_at"),
                "last_update": it.get("last_update")
            })
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)

# ---------- TAB 4: FAILED / REVIEW ----------

with tab4:
    st.subheader("🧪 Failed / Review Queue")
    items = [
        x for x in db.get("db", [])
        if x.get("status") in ("Failed", "AffiliateReview")
    ]
    if not items:
        st.info("No failed or review items right now.")
    else:
        rows = []
        for it in items:
            rows.append({
                "name": it.get("name"),
                "status": it.get("status"),
                "fail_count": it.get("fail_count", 0),
                "last_error": it.get("last_error", ""),
                "link": it.get("link")
            })
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)

# ---------- TAB 5: CONTENT VIEWER ----------

with tab5:
    st.subheader("📄 Content Viewer (Blog Preview)")
    items = [x for x in db.get("db", []) if x.get("generated", {}).get("blog_html")]
    if not items:
        st.info("No generated content yet. Once the engine runs, you'll see previews here.")
    else:
        options = {it.get("name"): it for it in items}
        choice = st.selectbox("Choose an item to preview:", list(options.keys()))
        selected = options[choice]
        html = selected.get("generated", {}).get("blog_html", "")
        st.components.v1.html(html, height=600, scrolling=True)

# ---------- TAB 6: LAUNCHPAD (placeholder) ----------

with tab6:
    st.subheader("🚀 Launchpad (Export & Distribution)")
    st.write("This is your one-click export hub. In this starter pack, it's a placeholder.")
    st.write("Future: Metricool CSV export, newsletter export, bundle zips, etc.")

# ---------- TAB 7: DTF NEWSWEEK (placeholder) ----------

with tab7:
    st.subheader("📧 DTF Newsweek (Weekly Roundup Builder)")
    st.write("This is where your weekly 'best of' tool roundup email will be stitched together.")
    st.write("For now, this starter build doesn't auto-generate the newsletter body, but the engine stores the pieces.")

# ---------- TAB 8: AFFILIATE QUEUE ----------

with tab8:
    st.subheader("🤝 Affiliate Program Intake")

    aff_items = [x for x in db.get("db", []) if x.get("status") == "AffiliateReview"]

    if not aff_items:
        st.info("No items waiting for affiliate review. Scout will add more when the pipeline is low.")
    else:
        summary_rows = []
        for it in aff_items:
            aff = it.get("affiliate_info") or {}
            summary_rows.append({
                "id": it.get("id"),
                "name": it.get("name"),
                "merchant_name": aff.get("merchant_name", ""),
                "has_affiliate_program": aff.get("has_affiliate_program", False),
                "affiliate_program_url": aff.get("affiliate_program_url", ""),
                "product_url_example": aff.get("product_url_example", ""),
                "notes": aff.get("notes", "")
            })

        df_aff = pd.DataFrame(summary_rows)
        st.dataframe(
            df_aff[[
                "name",
                "merchant_name",
                "has_affiliate_program",
                "affiliate_program_url",
                "product_url_example",
                "notes"
            ]],
            use_container_width=True
        )

        ids = [r["id"] for r in summary_rows]

        def label_aff(xid):
            for r in summary_rows:
                if r["id"] == xid:
                    return f"{r['name']} ({r['merchant_name'] or 'Unknown merchant'})"
            return xid

        selected_id = st.selectbox(
            "Select a tool to manage its affiliate setup:",
            ids,
            format_func=label_aff
        )

        selected_item = next((it for it in aff_items if it.get("id") == selected_id), None)

        if selected_item:
            aff = selected_item.get("affiliate_info") or {}
            st.markdown("---")
            st.markdown(f"### 🛠 {selected_item.get('name')}")

            if aff.get("affiliate_program_url"):
                st.markdown(
                    f"**Affiliate Program:** "
                    f"[Open application page]({aff['affiliate_program_url']})"
                )
            else:
                st.warning("No affiliate program URL found for this tool.")

            if aff.get("product_url_example"):
                st.markdown(
                    f"**Example product listing:** "
                    f"[View product page]({aff['product_url_example']})"
                )

            if aff.get("notes"):
                st.markdown(f"**Notes:** {aff['notes']}")

            st.markdown("----")
            st.markdown("#### 🔗 Add your unique affiliate link for this tool")

            existing_link = selected_item.get("link", "")
            my_link = st.text_input(
                "Paste your unique affiliate product link (with your tracking code):",
                value=existing_link,
                key=f"aff_link_{selected_id}"
            )

            colA, colB = st.columns(2)

            with colA:
                if st.button("💾 Save link (keep in Affiliate Review)", key=f"save_aff_{selected_id}"):
                    live_db = load_json(DB_FILE, {"db": []})
                    for item in live_db.get("db", []):
                        if item.get("id") == selected_id:
                            item["link"] = my_link.strip()
                            item["last_update"] = datetime.utcnow().isoformat()
                            break
                    save_json(DB_FILE, live_db)
                    st.success("Link saved. Item is still in AffiliateReview until you’re ready to push it into the pipeline.")
                    st.experimental_rerun()

            with colB:
                if st.button("✅ Save link & send to pipeline (Ready)", key=f"approve_aff_{selected_id}"):
                    if not my_link.strip():
                        st.error("You must paste your unique affiliate link before sending this to the pipeline.")
                    else:
                        live_db = load_json(DB_FILE, {"db": []})
                        for item in live_db.get("db", []):
                            if item.get("id") == selected_id:
                                item["link"] = my_link.strip()
                                item["status"] = "Ready"
                                item["last_update"] = datetime.utcnow().isoformat()
                                item["last_error"] = ""
                                break
                        save_json(DB_FILE, live_db)
                        st.success("Affiliate link saved and tool moved to Ready. It will go into production on the next engine cycle.")
                        st.experimental_rerun()
