DTF COMMAND HQ – EMPIRE OS V52
FIRST-TIME INSTALL KIT

FILES INCLUDED:
- EmpireInstaller_V52.py   -> creates the DTF_Command_HQ_V52 project folder and structure
- DTF_System_Check.py      -> checks Python, pip, ffmpeg, and API reachability
- DTF_Optimizer.bat        -> one-click Windows 11 optimization for Empire OS
- (You will paste engine.py and dtf_command_hq.py from ChatGPT into the generated folder)

RECOMMENDED FLOW:

1) Run the System Checker
   - Right-click DTF_System_Check.py > Open with Python
   - Fix anything marked with ❌ or ⚠ (Python, pip, ffmpeg, network)

2) Run the Installer
   - Right-click EmpireInstaller_V52.py > Open with Python
   - This creates: .\DTF_Command_HQ_V52 with subfolders and config files

3) Optimize Your PC (Optional but Recommended)
   - Right-click DTF_Optimizer.bat > Run as administrator
   - Reboot when it finishes

4) Install Python Dependencies
   - Open Command Prompt
   - cd into the new folder:
       cd DTF_Command_HQ_V52
   - Install requirements:
       pip install -r requirements.txt

5) Add Your Secrets
   - Open: .streamlit\secrets.toml
   - Fill in:
       openai_key
       pplx_key
       wp_url, wp_user, wp_pass (optional but required for auto-posting)

6) Paste Engine + Dashboard Code
   - Replace engine.py content with the full engine code from ChatGPT
   - Replace dtf_command_hq.py content with the full dashboard code from ChatGPT

7) Launch Your Empire
   - Double-click launch.bat
   - Your browser should open:
       http://localhost:8501

From there, use the dashboard to:
- Wire affiliate links
- Monitor notifications
- Adjust system thresholds
- Trigger backups

