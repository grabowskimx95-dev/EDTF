import shutil
import subprocess
import sys
import textwrap

def check_cmd(cmd):
    try:
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except Exception:
        return False

def main():
    print("="*60)
    print(" DTF Command HQ - Empire OS V52 System Checker")
    print("="*60)

    # Python
    print("\n[1/4] Checking Python...")
    print("python --version")
    try:
        out = subprocess.check_output("python --version", shell=True, stderr=subprocess.STDOUT)
        print(" OK:", out.decode().strip())
    except Exception:
        print(" ❌ Python not found. Install Python 3.10+ from https://www.python.org/downloads/windows/")

    # pip
    print("\n[2/4] Checking pip...")
    try:
        out = subprocess.check_output("pip --version", shell=True, stderr=subprocess.STDOUT)
        print(" OK:", out.decode().strip())
    except Exception:
        print(" ❌ pip not found. Try: python -m ensurepip --upgrade")

    # ffmpeg
    print("\n[3/4] Checking ffmpeg (for video generation)...")
    if shutil.which("ffmpeg"):
        print(" OK: ffmpeg is on PATH")
    else:
        print(" ⚠ ffmpeg not found. Empire OS will run, but video rendering will be disabled.")
        print("   Recommended download: https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-full.7z")

    # network sanity
    print("\n[4/4] Network sanity check (ping api.openai.com)...")
    if check_cmd("ping -n 1 api.openai.com"):
        print(" OK: Network looks reachable.")
    else:
        print(" ⚠ Could not reach api.openai.com. Check your internet, VPN, or firewall.")

    print("\nDone.")
    print("Next steps:")
    print(" - If Python/pip are missing, install them first.")
    print(" - If ffmpeg is missing, install it for video support (optional).")
    print(" - Then run EmpireInstaller_V52.py to install DTF Command HQ.")
    print("\nPress Enter to exit.")
    input()

if __name__ == '__main__':
    main()
