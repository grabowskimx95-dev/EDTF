\"\"\" 
EmpireInstaller_V52.py

One-shot installer for DTF Command HQ – Empire OS V52.

What this does when you run it:
- Creates a folder: ./DTF_Command_HQ_V52
- Creates subfolders: logs, packets, backups, .streamlit
- Writes:
    - engine.py         (V52: resource guard, ffmpeg check, log rotation, backups)
    - dtf_command_hq.py (upgraded dashboard with Notification Center, System Health, Backups)
    - requirements.txt
    - launch.bat        (Windows launcher)
    - .streamlit/secrets.toml (template)

After running this:
1) Open a terminal in the DTF_Command_HQ_V52 folder.
2) Run:  pip install -r requirements.txt
3) Double-click launch.bat to start the engine + dashboard.
\"\"\"

import os

PROJECT_DIR = "DTF_Command_HQ_V52"

# =========================
#  ENGINE CODE (V52)
# =========================
ENGINE_CODE = r'''PLACEHOLDER_ENGINE_CODE'''

# =========================
#  DASHBOARD CODE
# =========================
DASH_CODE = r'''PLACEHOLDER_DASH_CODE'''

# =========================
#  REQUIREMENTS
# =========================
REQUIREMENTS = \"\"\"streamlit
pandas
requests
moviepy<2.0
imageio
imageio-ffmpeg
toml
psutil
\"\"\"

# =========================
#  LAUNCH.BAT
# =========================
LAUNCH_BAT = r\"\"\"@echo off
TITLE DTF Command HQ - Empire OS V52
ECHO =================================================
ECHO   DTF Command HQ - Design To Finish Contracting
ECHO   Empire OS V52 - Blue Collar Content Engine
ECHO =================================================
ECHO.

ECHO Installing Python dependencies (one-time / as needed)...
pip install -r requirements.txt

ECHO Starting DTF Engine in background...
start /B pythonw engine.py

ECHO Starting DTF Command Dashboard (Streamlit)...
streamlit run dtf_command_hq.py

ECHO.
ECHO If a browser does not open automatically, go to:
ECHO   http://localhost:8501
ECHO.
PAUSE
\"\"\"

# =========================
#  SECRETS TEMPLATE
# =========================
SECRETS_TEMPLATE = \"\"\"# .streamlit/secrets.toml
# Fill these in before running launch.bat

openai_key   = "YOUR_OPENAI_API_KEY"
pplx_key     = "YOUR_PERPLEXITY_API_KEY"

wp_url       = "https://your-wordpress-site.com"
wp_user      = "your_wp_username"
wp_pass      = "your_wp_application_password"

daily_run_limit = 5
\"\"\"

def write_file(path, content: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def main():
    base = os.path.abspath(PROJECT_DIR)
    os.makedirs(base, exist_ok=True)

    print(f"Installing DTF Command HQ – Empire OS V52 into: {base}")

    logs_dir = os.path.join(base, "logs")
    packets_dir = os.path.join(base, "packets")
    backups_dir = os.path.join(base, "backups")
    streamlit_dir = os.path.join(base, ".streamlit")

    for d in [logs_dir, packets_dir, backups_dir, streamlit_dir]:
        os.makedirs(d, exist_ok=True)

    # NOTE: This installer contains placeholders for ENGINE_CODE and DASH_CODE.
    # Paste the full engine.py and dtf_command_hq.py code where indicated
    # if you want this script to generate them automatically.
    write_file(os.path.join(base, "engine.py"), "# TODO: paste engine.py code here")
    write_file(os.path.join(base, "dtf_command_hq.py"), "# TODO: paste dtf_command_hq.py code here")
    write_file(os.path.join(base, "requirements.txt"), REQUIREMENTS)
    write_file(os.path.join(base, "launch.bat"), LAUNCH_BAT)

    secrets_path = os.path.join(streamlit_dir, "secrets.toml")
    if not os.path.exists(secrets_path):
        write_file(secrets_path, SECRETS_TEMPLATE)

    print()
    print("✅ Base DTF Command HQ V52 structure created.")
    print()
    print("Next steps:")
    print(f"1) Open a terminal/Command Prompt in: {base}")
    print("2) Run:  pip install -r requirements.txt")
    print("3) Edit .streamlit\\secrets.toml with your keys and WP info")
    print("4) Replace engine.py and dtf_command_hq.py with the full versions from ChatGPT")
    print("5) Double-click launch.bat")
    print()
    print("The engine will start in the background and the dashboard will be at http://localhost:8501")

if __name__ == "__main__":
    main()
