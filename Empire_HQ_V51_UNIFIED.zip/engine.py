import base64
import json
import logging
import os
import re
import sqlite3
import time
from datetime import date, datetime

import requests
import toml
from moviepy.editor import AudioFileClip, ColorClip, CompositeVideoClip, ImageClip

# -----------------------------------------
# CONFIG
# -----------------------------------------
DB_FILE = "empire.db"
SECRETS_PATH = os.path.join(".streamlit", "secrets.toml")
LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "empire_activity.log")
PACKET_ROOT = "packets"

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(PACKET_ROOT, exist_ok=True)

# Logging: file + console
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(),
    ],
)


# -----------------------------------------
# DB HELPERS
# -----------------------------------------
def get_conn():
    return sqlite3.connect(DB_FILE)


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY,
            name TEXT UNIQUE,
            niche TEXT,
            link TEXT,
            status TEXT,
            app_url TEXT,
            image_url TEXT,
            created_at TEXT
        )
        """
    )

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS run_log (
            id INTEGER PRIMARY KEY,
            run_date TEXT,
            item_name TEXT
        )
        """
    )

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """
    )

    # NEW: error log table
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS error_log (
            id INTEGER PRIMARY KEY,
            item_name TEXT,
            stage TEXT,
            message TEXT,
            created_at TEXT
        )
        """
    )

    # Ensure system_status exists
    c.execute(
        """
        INSERT OR IGNORE INTO settings (key, value)
        VALUES ('system_status', 'RUNNING')
        """
    )

    conn.commit()
    conn.close()


def get_setting(key, default=None):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = c.fetchone()
    conn.close()
    if row:
        return row[0]
    return default


def set_setting(key, value):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()


def check_budget(daily_limit: int) -> bool:
    """Return True if we are still under budget."""
    conn = get_conn()
    c = conn.cursor()
    today = str(date.today())
    c.execute("SELECT COUNT(*) FROM run_log WHERE run_date = ?", (today,))
    count = c.fetchone()[0]
    conn.close()
    return count < daily_limit


def log_run(item_name: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO run_log (run_date, item_name) VALUES (?, ?)",
        (str(date.today()), item_name),
    )
    conn.commit()
    conn.close()


def update_status(name: str, status: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE posts SET status = ? WHERE name = ?", (status, name))
    conn.commit()
    conn.close()


def insert_scouted_product(name: str, niche: str, app_url: str):
    conn = get_conn()
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute(
        """
        INSERT OR IGNORE INTO posts (name, niche, link, status, app_url, image_url, created_at)
        VALUES (?, ?, '', 'Pending', ?, '', ?)
        """,
        (name, niche, app_url, now),
    )
    conn.commit()
    conn.close()


def get_ready_item():
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "SELECT id, name, niche, link, status, app_url FROM posts "
        "WHERE status = 'Ready' LIMIT 1"
    )
    row = c.fetchone()
    conn.close()
    return row


def get_pending_count():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM posts WHERE status = 'Pending'")
    count = c.fetchone()[0]
    conn.close()
    return count


# -----------------------------------------
# ERROR LOGGING
# -----------------------------------------
def log_error(item_name: str, stage: str, message: str):
    """
    Store an error in SQLite and log it to the main log.
    item_name: product name or 'SYSTEM'
    stage: e.g. 'scout', 'fact_check', 'content', 'media', 'wordpress', 'main_loop'
    message: short description (trimmed here)
    """
    message_short = (message or "").strip()
    if len(message_short) > 600:
        message_short = message_short[:600] + "...[truncated]"

    logging.error("Error [%s] %s: %s", stage, item_name, message_short)

    try:
        conn = get_conn()
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO error_log (item_name, stage, message, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (item_name, stage, message_short, datetime.utcnow().isoformat()),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        # If even error logging fails, just write to main log
        logging.error("Failed to write to error_log: %s", e)


# -----------------------------------------
# SECRETS
# -----------------------------------------
def load_secrets():
    if not os.path.exists(SECRETS_PATH):
        logging.warning("secrets.toml not found at %s", SECRETS_PATH)
        return {}

    try:
        return toml.load(SECRETS_PATH)
    except Exception as e:
        logging.error("Failed to load secrets.toml: %s", e)
        log_error("SYSTEM", "secrets", f"Failed to load secrets: {e}")
        return {}


# -----------------------------------------
# NETWORK HELPERS (HARDENED)
# -----------------------------------------
def safe_post(url, json_body, headers, timeout=30, item_name="SYSTEM", stage="network"):
    try:
        resp = requests.post(url, json=json_body, headers=headers, timeout=timeout)
        if resp.status_code != 200:
            msg = f"Status {resp.status_code}: {resp.text[:300]}"
            log_error(item_name, stage, msg)
            return None
        return resp
    except Exception as e:
        log_error(item_name, stage, f"POST {url} failed: {e}")
        return None


def safe_get(url, headers=None, timeout=30, item_name="SYSTEM", stage="network"):
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        if resp.status_code != 200:
            msg = f"Status {resp.status_code}: {resp.text[:300]}"
            log_error(item_name, stage, msg)
            return None
        return resp
    except Exception as e:
        log_error(item_name, stage, f"GET {url} failed: {e}")
        return None


# -----------------------------------------
# SCOUTING / FACT CHECK / CONTENT
# -----------------------------------------
def run_scout_real(niche: str, pplx_key: str):
    """Ask Perplexity for a short list of high-ticket tools."""
    logging.info("🔭 Scouting niche: %s", niche)
    if not pplx_key:
        msg = "Missing pplx_key in secrets.toml"
        logging.error(msg)
        log_error("SYSTEM", "scout", msg)
        return []

    url = "https://api.perplexity.ai/chat/completions"
    headers = {
        "Authorization": f"Bearer {pplx_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "llama-3.1-sonar-large-128k-online",
        "messages": [
            {
                "role": "system",
                "content": "List 3 specific, trending, high-ticket tools/products. "
                           "Return ONLY a comma-separated list of names.",
            },
            {
                "role": "user",
                "content": f"Best new tools for {niche} 2024-2025",
            },
        ],
    }
    resp = safe_post(url, payload, headers, item_name="SYSTEM", stage="scout")
    if not resp:
        return []

    try:
        content = resp.json()["choices"][0]["message"]["content"]
        items = [x.strip() for x in content.split(",") if x.strip()]
        return items[:3]
    except Exception as e:
        log_error("SYSTEM", "scout", f"Scout parsing error: {e}")
        return []


def find_app_link_real(product: str, pplx_key: str):
    """Ask Perplexity for affiliate signup URL."""
    if not pplx_key:
        msg = "Missing pplx_key for app link search"
        logging.error(msg)
        log_error(product, "affiliate_lookup", msg)
        return "https://google.com"

    url = "https://api.perplexity.ai/chat/completions"
    headers = {
        "Authorization": f"Bearer {pplx_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "llama-3.1-sonar-large-128k-online",
        "messages": [
            {
                "role": "system",
                "content": "Output ONLY the affiliate program signup URL. No extra text.",
            },
            {"role": "user", "content": f"Affiliate program for: {product}"},
        ],
    }
    resp = safe_post(url, payload, headers, item_name=product, stage="affiliate_lookup")
    if not resp:
        return "https://google.com"

    try:
        link = resp.json()["choices"][0]["message"]["content"].strip()
        if link.startswith("http"):
            return link
        return "https://google.com"
    except Exception as e:
        log_error(product, "affiliate_lookup", f"App link parsing error: {e}")
        return "https://google.com"


def get_product_facts(product: str, pplx_key: str):
    """Fact-check product to extract specs & pros/cons."""
    logging.info("🔎 Fact checking: %s", product)
    if not pplx_key:
        msg = "Missing pplx_key for fact check"
        logging.error(msg)
        log_error(product, "fact_check", msg)
        return "General tool overview."

    url = "https://api.perplexity.ai/chat/completions"
    headers = {
        "Authorization": f"Bearer {pplx_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "llama-3.1-sonar-large-128k-online",
        "messages": [
            {
                "role": "system",
                "content": "You are a technical researcher. Provide a bulleted list of the "
                           "top 5 technical specs and pros/cons for this product.",
            },
            {"role": "user", "content": f"Technical specs for: {product}"},
        ],
    }
    resp = safe_post(url, payload, headers, item_name=product, stage="fact_check")
    if not resp:
        return "General tool overview."

    try:
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as e:
        log_error(product, "fact_check", f"Fact check parsing error: {e}")
        return "General tool overview."


def create_content(product: str, facts: str, openai_key: str):
    """Create blog/social/script JSON object using OpenAI."""
    logging.info("📝 Writing content for: %s", product)
    if not openai_key:
        msg = "Missing openai_key"
        logging.error(msg)
        log_error(product, "content", msg)
        return None

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {openai_key}",
        "Content-Type": "application/json",
    }

    sys_prompt = f"""
    You are a veteran foreman. Use these facts to write content:
    FACTS: {facts}

    Output JSON ONLY:
    1. "blog_html": 800-word review, with H2s, pros and cons, rugged tone.
    2. "social_caption": Instagram caption with some emojis and hashtags.
    3. "video_script": 30-second narrator script (just spoken words).
    """

    payload = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": f"Write review for {product}"},
        ],
        "response_format": {"type": "json_object"},
    }

    resp = safe_post(
        url, payload, headers, timeout=60, item_name=product, stage="content"
    )
    if not resp:
        return None

    try:
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as e:
        log_error(product, "content", f"Content generation parsing error: {e}")
        return None


def produce_media(product: str, script: str, openai_key: str, base_dir: str):
    """Generate an image and TTS audio, optionally render a vertical video."""
    logging.info("🎨 Producing media for: %s", product)
    if not openai_key:
        msg = "Missing openai_key"
        logging.error(msg)
        log_error(product, "media", msg)
        return None, None, None

    h_oa = {
        "Authorization": f"Bearer {openai_key}",
        "Content-Type": "application/json",
    }

    # Image
    img_url = None
    try:
        img_payload = {
            "model": "dall-e-3",
            "prompt": f"Professional photography of {product} on a construction site, cinematic lighting.",
            "size": "1024x1024",
        }
        resp_img = safe_post(
            "https://api.openai.com/v1/images/generations",
            img_payload,
            h_oa,
            timeout=60,
            item_name=product,
            stage="media_image",
        )
        if resp_img:
            img_url = resp_img.json()["data"][0]["url"]
    except Exception as e:
        log_error(product, "media_image", f"Image generation failed: {e}")

    # Audio
    aud_bytes = None
    try:
        aud_payload = {
            "model": "tts-1",
            "input": script,
            "voice": "onyx",
        }
        resp_aud = safe_post(
            "https://api.openai.com/v1/audio/speech",
            aud_payload,
            h_oa,
            timeout=60 * 3,
            item_name=product,
            stage="media_audio",
        )
        if resp_aud:
            aud_bytes = resp_aud.content
    except Exception as e:
        log_error(product, "media_audio", f"Audio generation failed: {e}")

    if not img_url or not aud_bytes:
        log_error(
            product,
            "media",
            f"Media partial failure: img_url={bool(img_url)}, audio={bool(aud_bytes)}",
        )

    # Save files if available
    clean_name = re.sub(r"[^\w\s-]", "", product).strip().replace(" ", "_")
    img_path = os.path.join(base_dir, f"{clean_name}.jpg")
    aud_path = os.path.join(base_dir, f"{clean_name}.mp3")
    vid_path = os.path.join(base_dir, f"{clean_name}.mp4")

    # Download image
    if img_url:
        resp_img_data = safe_get(
            img_url, timeout=60, item_name=product, stage="media_image"
        )
        if resp_img_data:
            try:
                with open(img_path, "wb") as f:
                    f.write(resp_img_data.content)
            except Exception as e:
                log_error(product, "media_image", f"Failed to save image: {e}")
                img_path = None
        else:
            img_path = None
    else:
        img_path = None

    # Save audio
    if aud_bytes:
        try:
            with open(aud_path, "wb") as f:
                f.write(aud_bytes)
        except Exception as e:
            log_error(product, "media_audio", f"Failed to save audio: {e}")
            aud_path = None
    else:
        aud_path = None

    # Attempt video render
    if img_path and aud_path:
        try:
            ac = AudioFileClip(aud_path)
            duration = ac.duration + 0.5
            ic = ImageClip(img_path).set_duration(duration).resize(height=1920)
            if ic.w > 1080:
                x1 = ic.w / 2 - 540
                ic = ic.crop(x1=x1, y1=0, width=1080, height=1920)
            bc = ColorClip(size=(1080, 1920), color=(20, 20, 20), duration=duration)
            CompositeVideoClip([bc, ic]).set_audio(ac).write_videofile(
                vid_path, fps=24, verbose=False, logger=None
            )
            logging.info("🎬 Video rendered for %s", product)
        except Exception as e:
            log_error(product, "media_video", f"Video render failed: {e}")
            vid_path = None
    else:
        vid_path = None

    return img_path, aud_path, vid_path


def create_smart_link(wp_url: str, product_name: str, raw_link: str):
    clean = re.sub(r"[^\w\s-]", "", product_name).strip().replace(" ", "_")
    encoded = base64.b64encode(raw_link.encode("utf-8")).decode("utf-8")
    return f"{wp_url}/?df_track={clean}&dest={encoded}"


def publish_to_wordpress(
    name: str,
    blog_html: str,
    smart_link: str,
    img_path: str,
    secrets: dict,
):
    """Upload image + draft post to WordPress. Hardened with error checks."""
    wp_url = secrets.get("wp_url", "").rstrip("/")
    wp_user = secrets.get("wp_user", "")
    wp_pass = secrets.get("wp_pass", "")
    if not (wp_url and wp_user and wp_pass):
        msg = "Missing WP credentials or URL"
        logging.error(msg)
        log_error(name, "wordpress", msg)
        return None

    # Append CTA
    blog_html += (
        f"\n\n<div style='text-align:center;'>"
        f"<a href='{smart_link}' "
        f"style='background:red;color:white;padding:15px;"
        f"font-weight:bold;text-decoration:none;'>CHECK BEST PRICE</a></div>"
    )

    auth = base64.b64encode(f"{wp_user}:{wp_pass}".encode("utf-8")).decode("utf-8")

    # Upload image
    media_id = None
    if img_path and os.path.exists(img_path):
        headers_media = {
            "Authorization": f"Basic {auth}",
            "Content-Type": "image/jpeg",
            "Content-Disposition": "attachment; filename=feature.jpg",
        }
        try:
            with open(img_path, "rb") as f:
                img_bytes = f.read()
            resp_media = requests.post(
                f"{wp_url}/wp-json/wp/v2/media",
                data=img_bytes,
                headers=headers_media,
                timeout=60,
            )
            if resp_media.status_code in (200, 201):
                media_json = resp_media.json()
                media_id = media_json.get("id")
                image_url = media_json.get("source_url", "")
                logging.info("Image uploaded to WP for %s: id=%s", name, media_id)

                # Save image_url into DB
                conn = get_conn()
                c = conn.cursor()
                c.execute(
                    "UPDATE posts SET image_url = ? WHERE name = ?",
                    (image_url, name),
                )
                conn.commit()
                conn.close()
            else:
                msg = f"Media upload failed ({resp_media.status_code}): {resp_media.text[:300]}"
                log_error(name, "wordpress_media", msg)
        except Exception as e:
            log_error(name, "wordpress_media", f"Media upload exception: {e}")

    # Upload post
    headers_post = {
        "Authorization": f"Basic {auth}",
        "Content-Type": "application/json",
    }
    post_data = {
        "title": name,
        "content": blog_html,
        "status": "draft",  # safer to start as draft
    }
    if media_id:
        post_data["featured_media"] = media_id

    try:
        resp_post = requests.post(
            f"{wp_url}/wp-json/wp/v2/posts",
            json=post_data,
            headers=headers_post,
            timeout=60,
        )
        if resp_post.status_code in (200, 201):
            logging.info("✅ Published (draft) to WordPress: %s", name)
        else:
            msg = f"Post failed ({resp_post.status_code}): {resp_post.text[:300]}"
            log_error(name, "wordpress_post", msg)
    except Exception as e:
        log_error(name, "wordpress_post", f"WP post exception: {e}")


# -----------------------------------------
# PRODUCTION LINE (ONE ITEM)
# -----------------------------------------
def production_line(item_row, secrets):
    """
    item_row: (id, name, niche, link, status, app_url)
    """
    _, name, niche, link, status, app_url = item_row
    logging.info("🏗️ Manufacturing: %s (niche=%s)", name, niche)

    pplx_key = secrets.get("pplx_key", "")
    openai_key = secrets.get("openai_key", "")
    wp_url = secrets.get("wp_url", "")

    if not link:
        msg = "No affiliate link set"
        log_error(name, "precheck", msg)
        update_status(name, "Failed")
        return

    # 1. Fact check
    facts = get_product_facts(name, pplx_key)

    # 2. Content
    content_json = create_content(name, facts, openai_key)
    if not content_json:
        log_error(name, "content", "Content generation failed or empty.")
        update_status(name, "Failed")
        return

    try:
        assets = json.loads(content_json)
    except Exception as e:
        log_error(name, "content", f"JSON parse error: {e}")
        update_status(name, "Failed")
        return

    blog_html = assets.get("blog_html", "")
    social_caption = assets.get("social_caption", "")
    video_script = assets.get("video_script", "")

    if not blog_html:
        log_error(name, "content", "Missing blog_html in generated assets.")
        update_status(name, "Failed")
        return

    # 3. Media output directory
    today_str = datetime.now().strftime("%Y-%m-%d")
    # One folder per day for all assets
    day_dir = os.path.join(PACKET_ROOT, f"Daily_Packet_{today_str}")
    os.makedirs(day_dir, exist_ok=True)

    # 4. Media generation (image + audio + video)
    img_path, aud_path, vid_path = produce_media(
        name,
        video_script or f"{name} is built for real job sites.",
        openai_key,
        day_dir,
    )

    # 5. Smart link for blog CTA
    smart_link = create_smart_link(wp_url, name, link)

    # 6. Publish to WP (hardened)
    publish_to_wordpress(name, blog_html, smart_link, img_path, secrets)

    # 7. Mark as Published and log run
    update_status(name, "Published")
    log_run(name)
    logging.info("✅ Completed production for %s", name)


# -----------------------------------------
# MAIN AUTOPILOT LOOP
# -----------------------------------------
def autopilot_loop():
    logging.info("--- ENGINE V51 ONLINE ---")
    init_db()

    backoff = 30  # base backoff on fatal errors

    while True:
        try:
            secrets = load_secrets()
            openai_key = secrets.get("openai_key", "")
            pplx_key = secrets.get("pplx_key", "")
            daily_limit = int(secrets.get("daily_run_limit", 10))

            if not openai_key or not pplx_key:
                msg = "Missing API keys (openai_key or pplx_key)."
                logging.warning(msg)
                log_error("SYSTEM", "main_loop", msg)
                time.sleep(30)
                continue

            # Check kill switch
            system_status = get_setting("system_status", "RUNNING")
            if system_status != "RUNNING":
                logging.info("🛑 Engine is stopped via dashboard. Sleeping 60s...")
                time.sleep(60)
                continue

            # Budget check
            if not check_budget(daily_limit):
                msg = f"Daily budget hit ({daily_limit})."
                logging.info("💤 " + msg + " Sleeping 1 hour...")
                log_error("SYSTEM", "budget", msg)
                time.sleep(3600)
                continue

            # 1. If there's a READY item, process it
            item = get_ready_item()
            if item:
                production_line(item, secrets)
                # short pause between runs to avoid hammering APIs
                time.sleep(10)
                backoff = 30  # reset backoff after successful cycle
                continue

            # 2. If no READY and no PENDING, scout
            pending_count = get_pending_count()
            if pending_count == 0:
                logging.info("BLUE LIGHT - Pipeline empty. Auto-scouting...")
                items = run_scout_real("Construction Tools", pplx_key)
                for name in items:
                    app_url = find_app_link_real(name, pplx_key)
                    insert_scouted_product(name, "Tools", app_url)
                    logging.info("🔭 Found candidate: %s", name)
                # Give UI time to show new pending items
                time.sleep(60)
                backoff = 30
                continue

            # 3. Otherwise, there are PENDING items waiting for links
            logging.info(
                "RED LIGHT - %s items pending affiliate links. Waiting 5 minutes.",
                pending_count,
            )
            time.sleep(300)
            backoff = 30

        except Exception as e:
            msg = f"System error in main loop: {e}"
            logging.error(msg)
            log_error("SYSTEM", "main_loop", msg)
            # exponential-ish backoff up to a cap
            time.sleep(backoff)
            backoff = min(backoff * 2, 900)  # cap at 15 minutes


if __name__ == "__main__":
    autopilot_loop()
