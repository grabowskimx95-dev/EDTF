import os
import sqlite3
from datetime import date, datetime

import pandas as pd
import streamlit as st
import toml

# -----------------------------------------
# CONFIG
# -----------------------------------------
DB_FILE = "empire.db"
LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "empire_activity.log")

os.makedirs(LOG_DIR, exist_ok=True)


# -----------------------------------------
# DB HELPERS
# -----------------------------------------
def get_conn():
    return sqlite3.connect(DB_FILE)


def init_db():
    conn = get_conn()
    c = conn.cursor()

    # Main content table
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY,
            name TEXT UNIQUE,
            niche TEXT,
            link TEXT,
            status TEXT,
            app_url TEXT,
            image_url TEXT,
            created_at TEXT
        )
        """
    )

    # Budget tracking
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS run_log (
            id INTEGER PRIMARY KEY,
            run_date TEXT,
            item_name TEXT
        )
        """
    )

    # Settings (for kill switch, etc.)
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """
    )

    # Error log table (must match engine.py)
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS error_log (
            id INTEGER PRIMARY KEY,
            item_name TEXT,
            stage TEXT,
            message TEXT,
            created_at TEXT
        )
        """
    )

    # Ensure system_status exists
    c.execute(
        """
        INSERT OR IGNORE INTO settings (key, value)
        VALUES ('system_status', 'RUNNING')
        """
    )

    conn.commit()
    conn.close()


def get_setting(key, default=None):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = c.fetchone()
    conn.close()
    if row:
        return row[0]
    return default


def set_setting(key, value):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()


def get_counts():
    conn = get_conn()
    c = conn.cursor()

    c.execute("SELECT COUNT(*) FROM posts WHERE status = 'Pending'")
    pending = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM posts WHERE status = 'Ready'")
    ready = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM posts WHERE status = 'Published'")
    published = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM posts WHERE status = 'Failed'")
    failed = c.fetchone()[0]

    conn.close()
    return pending, ready, published, failed


def get_runs_today():
    today = str(date.today())
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM run_log WHERE run_date = ?", (today,))
    count = c.fetchone()[0]
    conn.close()
    return count


def get_all_posts():
    conn = get_conn()
    df = pd.read_sql_query("SELECT * FROM posts ORDER BY id DESC", conn)
    conn.close()
    return df


def get_pending_posts():
    conn = get_conn()
    df = pd.read_sql_query(
        "SELECT id, name, app_url, link FROM posts WHERE status = 'Pending' ORDER BY id DESC",
        conn,
    )
    conn.close()
    return df


def update_links_from_df(df):
    conn = get_conn()
    c = conn.cursor()
    for _, row in df.iterrows():
        link_val = (row.get("link") or "").strip()
        if not link_val:
            continue
        c.execute(
            "UPDATE posts SET link = ?, status = 'Ready' WHERE id = ?",
            (link_val, int(row["id"])),
        )
    conn.commit()
    conn.close()


def get_published_for_export():
    conn = get_conn()
    df = pd.read_sql_query(
        "SELECT name, image_url, link FROM posts WHERE status = 'Published'",
        conn,
    )
    conn.close()
    return df


# ---------- ERROR LOG HELPERS ----------
def get_error_stats():
    conn = get_conn()
    c = conn.cursor()

    today_str = str(date.today())
    c.execute(
        "SELECT COUNT(*) FROM error_log WHERE created_at LIKE ?",
        (today_str + "%",),
    )
    today_errors = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM error_log")
    total_errors = c.fetchone()[0]

    c.execute("SELECT created_at FROM error_log ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    last_error_time = row[0] if row else None

    conn.close()
    return today_errors, total_errors, last_error_time


def get_recent_errors(limit=200):
    conn = get_conn()
    df = pd.read_sql_query(
        "SELECT * FROM error_log ORDER BY id DESC LIMIT ?", conn, params=(limit,)
    )
    conn.close()
    return df


# -----------------------------------------
# SECRETS LOADING
# -----------------------------------------
def load_secrets():
    # Prefer streamlit secrets if running via `streamlit run`
    try:
        secrets = st.secrets  # type: ignore[attr-defined]
        return dict(secrets)
    except Exception:
        pass

    # Fallback to direct TOML read
    secrets_path = os.path.join(".streamlit", "secrets.toml")
    if os.path.exists(secrets_path):
        return toml.load(secrets_path)

    return {}


# -----------------------------------------
# STREAMLIT UI
# -----------------------------------------
init_db()
SECRETS = load_secrets()
DAILY_LIMIT = int(SECRETS.get("daily_run_limit", 10))

st.set_page_config(
    page_title="Empire Commander V51",
    page_icon="🏢",
    layout="wide",
)

system_status = get_setting("system_status", "RUNNING")
pending_count, ready_count, published_count, failed_count = get_counts()
runs_today = get_runs_today()
today_errors, total_errors, last_error_time = get_error_stats()

# ---------- SIDEBAR ----------
with st.sidebar:
    st.title("🏢 EMPIRE COMMANDER V51")

    # Status HUD
    if system_status == "STOPPED":
        st.error("🔴 ENGINE STOPPED")
    else:
        if pending_count > 0:
            st.error(f"🔴 {pending_count} links needed")
        elif ready_count > 0:
            st.warning(f"🟡 {ready_count} items queued")
        else:
            st.success("🟢 SYSTEM: Idle / Scouting")

    st.metric("Daily Budget Used", f"{runs_today}/{DAILY_LIMIT}")
    st.metric("Published Items", published_count)
    st.metric("Failed Items", failed_count)
    st.metric("Errors Today", today_errors)

    st.markdown("---")
    st.subheader("Engine Control")

    if system_status == "RUNNING":
        if st.button("🛑 Emergency Stop"):
            set_setting("system_status", "STOPPED")
            st.experimental_rerun()
    else:
        if st.button("♻️ Restart Engine"):
            set_setting("system_status", "RUNNING")
            st.experimental_rerun()

    st.markdown("---")
    if last_error_time:
        st.caption(f"Last error at: {last_error_time}")
    else:
        st.caption("No errors logged yet.")

    st.caption("API keys and limits are managed in `.streamlit/secrets.toml`")

# ---------- MAIN LAYOUT ----------
st.title("🏗️ Empire OS – Glass Cockpit (V51 Unified)")

col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.metric("Pending", pending_count)
with col2:
    st.metric("Ready", ready_count)
with col3:
    st.metric("Published", published_count)
with col4:
    st.metric("Failed", failed_count)
with col5:
    st.metric("Errors (Total)", total_errors)

st.markdown("---")

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    [
        "⚡ Link Input",
        "📜 Live Logs",
        "📊 Pipeline",
        "📦 Distribution",
        "🧯 Error Center",
    ]
)

# ---------- TAB 1: LINK INPUT ----------
with tab1:
    st.subheader("🔴 Links Needed for Production")

    df_pending = get_pending_posts()
    if df_pending.empty:
        st.success("✅ No pending items. The engine will scout or work as needed.")
    else:
        # Show editable table
        display_cols = ["id", "name", "app_url", "link"]

        edited_df = st.data_editor(
            df_pending[display_cols],
            column_config={
                "id": st.column_config.NumberColumn("ID", disabled=True),
                "name": st.column_config.TextColumn("Product", disabled=True),
                "app_url": st.column_config.LinkColumn(
                    "Apply Page", display_text="👉 Open Application"
                ),
                "link": st.column_config.TextColumn(
                    "Affiliate Link (Paste Here)", width="large", required=False
                ),
            },
            hide_index=True,
            key="pending_editor",
        )

        if st.button("✅ SAVE LINKS & QUEUE FOR PRODUCTION"):
            update_links_from_df(edited_df)
            st.success("Links saved. Items moved to 'Ready'.")
            st.experimental_rerun()

# ---------- TAB 2: LIVE LOGS ----------
with tab2:
    st.subheader("🖥️ Engine Log (Last 100 lines)")
    if st.button("🔄 Refresh Logs"):
        st.experimental_rerun()

    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        last_lines = "".join(lines[-100:])
        st.code(last_lines or "[log file empty]", language="bash")
    else:
        st.info("Log file not found yet. Start the engine first.")

# ---------- TAB 3: PIPELINE ----------
with tab3:
    st.subheader("📊 Full Pipeline View")
    df_all = get_all_posts()
    if df_all.empty:
        st.info("No items in database yet. Once the engine scouts, they’ll appear here.")
    else:
        st.dataframe(df_all, use_container_width=True)

# ---------- TAB 4: DISTRIBUTION ----------
with tab4:
    st.subheader("📦 Social Scheduler Export (Metricool-style CSV)")
    df_pub = get_published_for_export()
    if df_pub.empty:
        st.info("No published content yet.")
    else:
        # Basic CSV with caption/image/link; caption is simple for now
        rows = ["Text,Image/Video URL,Link"]
        for _, row in df_pub.iterrows():
            name = row["name"]
            img = row.get("image_url") or ""
            link = row.get("link") or ""
            caption = f"Check out {name}."
            # Escape double quotes
            caption = caption.replace('"', '""')
            img = img.replace('"', '""')
            link = link.replace('"', '""')
            rows.append(f"\"{caption}\",\"{img}\",\"{link}\"")

        csv_data = "\n".join(rows)
        st.download_button(
            "⬇️ Download CSV",
            data=csv_data,
            file_name="social_schedule.csv",
            mime="text/csv",
        )

# ---------- TAB 5: ERROR CENTER ----------
with tab5:
    st.subheader("🧯 Error Center – Diagnostics & Triage")

    # Summary metrics
    col_a, col_b, col_c = st.columns(3)
    with col_a:
        st.metric("Errors Today", today_errors)
    with col_b:
        st.metric("Total Errors", total_errors)
    with col_c:
        st.metric("Failed Items", failed_count)

    st.markdown("---")

    df_errors = get_recent_errors(limit=200)
    if df_errors.empty:
        st.success("No errors logged. System is clean.")
    else:
        # Filter controls
        stages = sorted(df_errors["stage"].dropna().unique().tolist())
        items = sorted(df_errors["item_name"].dropna().unique().tolist())

        col_f1, col_f2 = st.columns(2)
        with col_f1:
            stage_filter = st.selectbox(
                "Filter by stage", options=["(All)"] + stages, index=0
            )
        with col_f2:
            item_filter = st.selectbox(
                "Filter by item", options=["(All)"] + items, index=0
            )

        df_view = df_errors.copy()
        if stage_filter != "(All)":
            df_view = df_view[df_view["stage"] == stage_filter]
        if item_filter != "(All)":
            df_view = df_view[df_view["item_name"] == item_filter]

        st.caption("Showing the most recent errors (up to 200).")
        st.dataframe(df_view, use_container_width=True)

        with st.expander("How to use this"):
            st.write(
                """
- **stage** tells you *where* the failure happened:
  - `scout`, `affiliate_lookup`, `fact_check`, `content`, `media_*`, `wordpress_*`, `budget`, `main_loop`, etc.
- **item_name** is either a product name or `SYSTEM`.
- **message** is a trimmed version of the real error message.

Start by filtering by stage = `content` or `wordpress_post` to see which products are failing most often.
"""
            )
