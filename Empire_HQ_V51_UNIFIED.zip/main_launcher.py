import os
import subprocess
import time
import webbrowser


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Start engine
    engine_path = os.path.join(base_dir, "engine.py")
    subprocess.Popen(["python", engine_path], cwd=base_dir)

    # Start Streamlit dashboard
    app_path = os.path.join(base_dir, "empire_app.py")
    subprocess.Popen(["streamlit", "run", app_path], cwd=base_dir)

    # Give it a moment to spin up, then try opening the browser
    time.sleep(3)
    try:
        webbrowser.open("http://localhost:8501")
    except Exception:
        pass


if __name__ == "__main__":
    main()
